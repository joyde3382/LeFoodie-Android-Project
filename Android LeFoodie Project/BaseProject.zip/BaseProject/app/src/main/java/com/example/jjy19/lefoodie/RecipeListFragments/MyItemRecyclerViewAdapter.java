package com.example.jjy19.lefoodie.RecipeListFragments;

import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import com.bumptech.glide.Glide;
import com.example.jjy19.lefoodie.MainActivity;
import com.example.jjy19.lefoodie.Models.Recipe;
import com.example.jjy19.lefoodie.R;
import com.example.jjy19.lefoodie.RecipeListActivity;
import com.example.jjy19.lefoodie.RecipeListFragments.RecipeFragment.OnListFragmentInteractionListener;

import java.text.DecimalFormat;
import java.util.List;

/**
 * {@link RecyclerView.Adapter} that can display a {@link com.example.jjy19.lefoodie.Models.Recipe} and makes a call to the
 * specified {@link OnListFragmentInteractionListener}.
 */
public class MyItemRecyclerViewAdapter extends RecyclerView.Adapter<MyItemRecyclerViewAdapter.ViewHolder> {

    private final List<Recipe> mValues;
    private final OnListFragmentInteractionListener mListener;

    public MyItemRecyclerViewAdapter(List<Recipe> items, OnListFragmentInteractionListener listener) {
        mValues = items;
        mListener = listener;
    }

    @Override
    public ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.layout_recipe_content, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(final ViewHolder holder, int position) {
        final Recipe myRecipe = mValues.get(position);
        holder.recipeName.setText(myRecipe.getName());
        holder.recipeCalories.setText(String.valueOf(new DecimalFormat("##.##").format(myRecipe.getCalories()) + " Kcal")); // universal, won't be externalized
        Glide.with((RecipeListActivity)mListener).load(myRecipe.getImageLink()).into(holder.recipeImage);

        holder.mView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (null != mListener) {
                    mListener.onListFragmentInteraction(myRecipe);
                }
            }
        });
    }

    @Override
    public int getItemCount() {
        return mValues.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder {
        public final View mView;
        public final TextView recipeName;
        public final TextView recipeCalories;
        public final ImageView recipeImage;

        public ViewHolder(View view) {
            super(view);
            mView = view;
            recipeName = view.findViewById(R.id.recipeName);
            recipeCalories = view.findViewById(R.id.recipeCalories);
            recipeImage = view.findViewById(R.id.recipeImage);
        }
    }
}
