package com.example.jjy19.lefoodie.Database.Room;

import android.arch.lifecycle.LiveData;
import android.arch.persistence.room.Dao;
import android.arch.persistence.room.Delete;
import android.arch.persistence.room.Insert;
import android.arch.persistence.room.Query;
import android.arch.persistence.room.Update;

import com.example.jjy19.lefoodie.Models.Ingredient;
import com.example.jjy19.lefoodie.Models.IngredientList;

import java.util.ArrayList;
import java.util.List;

import static android.arch.persistence.room.OnConflictStrategy.REPLACE;


// Got inspiration from
// https://proandroiddev.com/android-room-handling-relations-using-livedata-2d892e40bd53
@Dao
public interface IngredientListDAO {

    // LIST
    @Query("SELECT * FROM ingredientlist")
    LiveData<List<IngredientList>> getAll();

    @Query("SELECT * FROM ingredientlist WHERE uid = :id")
    IngredientList getIngredientList(int id);

    @Insert(onConflict = REPLACE)
    void saveIngredientLists(List<IngredientList> lists);

    @Insert(onConflict = REPLACE)
    void saveIngredientList(IngredientList list);

    @Delete
    void deleteIngredientList(IngredientList list);

    // INGREDIENTS
    @Query("SELECT * FROM ingredient WHERE listId = :listId")
    LiveData<List<Ingredient>> getIngredientsOnList(int listId);

    @Query("SELECT name FROM ingredient")
    List<String> getAllIngredientNames();

    @Insert(onConflict = REPLACE)
    void saveIngredient(Ingredient ingredient);

    @Insert(onConflict = REPLACE)
    void saveIngredients(List<Ingredient> ingredients);

    @Update
    void updateIngredient(Ingredient ingredient);
}