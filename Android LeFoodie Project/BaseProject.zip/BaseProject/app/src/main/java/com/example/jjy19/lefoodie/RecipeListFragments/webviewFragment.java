package com.example.jjy19.lefoodie.RecipeListFragments;

import android.content.Context;
import android.net.Uri;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.webkit.WebView;

import com.example.jjy19.lefoodie.Models.Recipe;
import com.example.jjy19.lefoodie.R;

public class webviewFragment extends Fragment {
    private OnFragmentInteractionListener mListener;
    WebView webview;

    public webviewFragment() {}

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    }

    public Recipe getTargetRecipe() {
        return targetRecipe;
    }

    public void setTargetRecipe(Recipe targetRecipe) {
        this.targetRecipe = targetRecipe;
    }

    Recipe targetRecipe;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view = inflater.inflate(R.layout.fragment_webview, container, false);
        webview = view.findViewById(R.id.recipeWebView);
        webview.loadUrl(targetRecipe.getRecipeLink());
        return view;
    }

    public void onButtonPressed(Uri uri) {
        if (mListener != null) {
            mListener.onFragmentInteraction(uri);
        }
    }

    @Override
    public void onAttach(Context context) {
        super.onAttach(context);
        if (context instanceof OnFragmentInteractionListener) {
            mListener = (OnFragmentInteractionListener) context;
        } else {
            throw new RuntimeException(context.toString()
                    + " must implement OnFragmentInteractionListener");
        }
    }

    @Override
    public void onDetach() {
        super.onDetach();
        mListener = null;
    }

    public interface OnFragmentInteractionListener {
        void onFragmentInteraction(Uri uri);
    }
}
