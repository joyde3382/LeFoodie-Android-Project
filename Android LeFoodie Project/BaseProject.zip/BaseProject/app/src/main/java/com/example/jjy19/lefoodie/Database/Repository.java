package com.example.jjy19.lefoodie.Database;

import android.arch.lifecycle.LiveData;
import android.content.Context;
import android.os.AsyncTask;

import com.example.jjy19.lefoodie.Database.StorageStrategy.CloudStrategy;
import com.example.jjy19.lefoodie.Database.StorageStrategy.IStorageStrategy;
import com.example.jjy19.lefoodie.Database.StorageStrategy.LocalStrategy;
import com.example.jjy19.lefoodie.Models.Ingredient;
import com.example.jjy19.lefoodie.Models.IngredientList;
import com.example.jjy19.lefoodie.Models.User;

import java.util.Arrays;
import java.util.List;
import java.util.concurrent.ExecutionException;

public class Repository {

    // FIELDS
    private static IStorageStrategy storage_;
    private Context context_;
    private SharedPreferenceHelper spHelper_;

    // CONSTRUCTION
    public Repository(Context context) {

        context_ = context;
        spHelper_ = new SharedPreferenceHelper(context.getSharedPreferences(spHelper_.SharedPrefName, context.MODE_PRIVATE));

        if(spHelper_.needsSync()){
            // Local strategy
            storage_ = new CloudStrategy();
        }
        else{
            storage_ = new LocalStrategy(context);
        }
    }

    // INGREDIENT LIST METHODS
    public LiveData<List<IngredientList>> getAll() {
        try {

            return (new getAllTask(storage_).execute().get());
            
       } catch (Exception e) {
           e.printStackTrace();
           return null;
       }
    }

    public IngredientList getIngredientList(int id){
        try {

            return (new getListTask(storage_).execute(id).get());

        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }

    public void createNewList(String name, boolean shared){
        IngredientList newList = new IngredientList(name, shared);
        new addListTask(storage_).execute(newList);
    }

    public void updateList(IngredientList list){
        new updateListTask(storage_).execute(list);
    }

    public void deleteList(IngredientList list){
        new deleteListTask(storage_).execute(list);
    }

    // INGREDIENT METHODS
    public void insertIngredient(Ingredient ingredient, IngredientList list) {
        new insertIngredientTask(storage_, ingredient, list).execute();
    }

    public List<String> getAllIngredientNames(){
        try {

            return (new getIngredientNamesTask(storage_).execute().get());

        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }

    public void updateIngredient(Ingredient ingredient, IngredientList list) {
        new updateIngredient(storage_, ingredient, list).execute();
    }

    public void deleteIngredient(Ingredient ingredient, IngredientList list) {
        // Just updating
        ingredient.setDeleted(true);
        updateIngredient(ingredient, list);
    }

    // SYNC
    public void changeSync(boolean syncing, List<IngredientList> lists) {

        // Check if state has actually changed
        if(syncing != spHelper_.previousSyncState()){
            spHelper_.setPreviousSyncState(syncing);

            IStorageStrategy newStrat;

            if(syncing){
                // FIREBASE
                newStrat = new CloudStrategy();
            }
            else {
                // ROOM
                newStrat = new LocalStrategy(context_);
            }

            try { // Wait till finished before changing the storage variable
                new changeSyncTask(lists, newStrat, spHelper_.getUser()).execute();
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    }


    // ASYNC TASKS FOR LIST
    private static class getAllTask extends AsyncTask<Void, Void, LiveData<List<IngredientList>>>{
        private IStorageStrategy storage;
        getAllTask(IStorageStrategy s){ storage = s; }

        @Override
        protected LiveData<List<IngredientList>> doInBackground(Void... voids) {
            return storage.getAll();
        }
    }

    private static class getListTask extends AsyncTask<Integer, Void, IngredientList>{
        private IStorageStrategy storage;
        getListTask(IStorageStrategy s){ storage = s; }

        @Override
        protected IngredientList doInBackground(Integer... integers) {
            return storage.getIngredientList(integers[0]);
        }
    }

    private static class addListTask extends AsyncTask<IngredientList, Void, Void>{
        private IStorageStrategy storage;
        addListTask(IStorageStrategy s){ storage = s; }

        @Override
        protected Void doInBackground(IngredientList... ingredientLists) {
            storage.saveList(ingredientLists[0]);
            return null;
        }
    }

    private static class updateListTask extends AsyncTask<IngredientList, Void, Void>{
        private IStorageStrategy storage;
        updateListTask(IStorageStrategy s){ storage = s; }

        @Override
        protected Void doInBackground(IngredientList... ingredientLists) {
            storage.updateList(ingredientLists[0]);
            return null;
        }
    }

    private static class deleteListTask extends AsyncTask<IngredientList, Void, Void>{
        private IStorageStrategy storage;
        deleteListTask(IStorageStrategy s){ storage = s; }

        @Override
        protected Void doInBackground(IngredientList... ingredientLists) {
            storage.deleteList(ingredientLists[0]);
            return null;
        }
    }

    // ASYNC TASKS FOR INGREDIENTS
    private static class insertIngredientTask extends AsyncTask<Void, Void, Void>{
        private IStorageStrategy storage;
        private Ingredient ingredient;              // Dirty add through constructor
        private IngredientList ingredientList;      // Dirty add through constructor
        insertIngredientTask(IStorageStrategy s, Ingredient i, IngredientList l){ storage = s; ingredient = i; ingredientList = l; }

        @Override
        protected Void doInBackground(Void... voids) {
            ingredient.setListId(ingredientList.uid);
            storage.insertIngredient(ingredient, ingredientList);
            return null;
        }
    }

    private static class getIngredientNamesTask extends AsyncTask<Void, Void, List<String>>{
        private IStorageStrategy storage;
        getIngredientNamesTask(IStorageStrategy s){ storage = s; }

        @Override
        protected List<String> doInBackground(Void... voids) {
            return storage.getAllIngredientNames();
        }
    }

    private static class updateIngredient extends AsyncTask<Void, Void, Void>{
        private IStorageStrategy storage;
        private Ingredient i;
        private IngredientList l;
        updateIngredient(IStorageStrategy s, Ingredient ip, IngredientList lp){ storage = s; i = ip; l = lp; }

        @Override
        protected Void doInBackground(Void... voids) {
            storage.updateIngredient(i, l);
            return null;
        }
    }

    private class changeSyncTask extends AsyncTask<Void, Void, IStorageStrategy>{
        private List<IngredientList> lists;
        private IStorageStrategy newStorage;
        private User user;
        changeSyncTask(List<IngredientList> old, IStorageStrategy newsies, User u){
            lists = old;
            newStorage = newsies;
            user = u;
        }

        @Override
        protected IStorageStrategy doInBackground(Void... voids) {
            // Append user for good measure.
            // List will be empty coming from room
            // List will become empty entering room
            for(IngredientList list : lists){
                list.setUsers(Arrays.asList(user));
            }

            newStorage.insertListsWhenChaningSync(lists);
            return newStorage;
        }

        @Override
        protected void onPostExecute(IStorageStrategy strat) {
            setNewStrat(strat);
            super.onPostExecute(strat);
        }
    }

    private void setNewStrat(IStorageStrategy strat){
        storage_ = strat;
    }
}
