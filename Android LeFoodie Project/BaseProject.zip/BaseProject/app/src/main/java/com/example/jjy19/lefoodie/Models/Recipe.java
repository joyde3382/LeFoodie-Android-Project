package com.example.jjy19.lefoodie.Models;

public class Recipe {

    private String label;
    private String image;
    private double calories;
    private String url;

    public String getName() {
        return label;
    }

    public void setName(String name) {
        this.label = name;
    }

    public String getImageLink() {
        return image;
    }

    public void setImageLink(String imageLink) {
        this.image = imageLink;
    }

    public double getCalories() {
        return calories;
    }

    public void setCalories(int calories) {
        this.calories = calories;
    }

    public String getRecipeLink() {
        return url;
    }

    public void setRecipeLink(String recipeLink) {
        this.url = recipeLink;
    }

    public Recipe(String name, String imageLink, int calories, String recipeLink) {

        this.label = name;
        this.image = imageLink;
        this.calories = calories;
        this.url = recipeLink;
    }
}
