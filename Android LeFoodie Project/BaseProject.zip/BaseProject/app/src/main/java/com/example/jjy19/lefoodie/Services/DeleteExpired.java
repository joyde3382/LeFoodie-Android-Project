package com.example.jjy19.lefoodie.Services;

import android.app.NotificationManager;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.support.v4.app.NotificationCompat;
import com.example.jjy19.lefoodie.Database.Repository;
import com.example.jjy19.lefoodie.MainActivity;
import com.example.jjy19.lefoodie.Models.Ingredient;
import com.example.jjy19.lefoodie.Models.IngredientList;
import com.example.jjy19.lefoodie.R;

import java.util.Date;
import java.util.List;

import static android.content.Context.NOTIFICATION_SERVICE;

public class DeleteExpired extends BroadcastReceiver {
    private final static String TAG = "DeleteExpired";
    Repository repository;
    NotificationManager notificationManager;
    @Override
    public void onReceive(Context context, Intent intent) {
        repository = new Repository(context);
        notificationManager = (NotificationManager)context.getSystemService(NOTIFICATION_SERVICE);
        deleteExpiredIngredients(context);
    }
    private void deleteExpiredIngredients(Context context){
        List<IngredientList> lists = MainActivity.myList;

        if(lists != null){

            // Going to use the for(IngredientList list : lists) next time, homie..
            for(int i = 0; i != lists.size(); i++){
                IngredientList ingredientList = lists.get(i);
                List<Ingredient> ingredients = ingredientList.getIngredients();
                for(int y = 0; y!=ingredients.size(); y++){
                    Ingredient ingredient = ingredients.get(y);
                    if(ingredient.getExperiation().before(new Date()) && !ingredient.isDeleted()) {
                        repository.deleteIngredient(ingredient, ingredientList);
                        createNotification(ingredient.getName() + " " + context.getString(R.string.notification_message), context);
                    }
                }
            }
        }
    }
    public void createNotification(String message, Context context){
        NotificationCompat.Builder notification = new NotificationCompat.Builder(context, "RecipeChannelId" )
                .setSmallIcon(R.drawable.ic_search_black_24dp)
                .setContentTitle(context.getResources().getString(R.string.notification_title))
                .setContentText(message)
                .setPriority(NotificationCompat.PRIORITY_DEFAULT)
                .setOnlyAlertOnce(true);
        NotificationManager manager = (NotificationManager) context.getSystemService (NOTIFICATION_SERVICE);
        manager.notify(1, notification.build());
    }
}
