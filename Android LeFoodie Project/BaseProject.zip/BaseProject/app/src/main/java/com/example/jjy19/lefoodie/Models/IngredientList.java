package com.example.jjy19.lefoodie.Models;

import android.arch.persistence.room.Entity;
import android.arch.persistence.room.Ignore;
import android.arch.persistence.room.PrimaryKey;

import java.util.ArrayList;
import java.util.List;

@Entity
public class IngredientList {

    @PrimaryKey(autoGenerate = true)
    public int uid;

    // Ignored since room can't handle the one-to-many
    @Ignore
    private List<User> users;
    @Ignore
    private List<Ingredient> ingredients;
    private String name;
    private Boolean sharable;

    // CONSTRUCTION
    public IngredientList(String name, Boolean sharable) {
        this.users = new ArrayList<User>();
        this.ingredients = new ArrayList<Ingredient>();
        this.name = name;
        this.sharable = sharable;
    }

    public IngredientList(){
        this("", false);
    }

    // GETTER AND SETTER
    public List<Ingredient> getIngredients() {
        return ingredients;
    }

    public void setIngredients(List<Ingredient> ingredients) {
        this.ingredients = ingredients;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public Boolean getSharable() {
        return sharable;
    }

    public void setSharable(Boolean sharable) {
        this.sharable = sharable;
    }

    public List<User> getUsers() {
        return users;
    }

    public void setUsers(List<User> users) {
        this.users = users;
    }
}
