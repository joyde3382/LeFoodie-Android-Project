package com.example.jjy19.lefoodie.MainActivityFragments;

import android.content.Context;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentPagerAdapter;
import android.support.v4.app.FragmentStatePagerAdapter;

import java.util.ArrayList;

// Inspired from https://guides.codepath.com/android/viewpager-with-fragmentpageradapter#viewpager-with-visible-adjacent-pages
// and https://gist.github.com/cesco89/11008973
public class IngridientViewPagerAdapter extends FragmentStatePagerAdapter {

    public static int pos = 0;
    private ArrayList<Fragment> fragmentsList = new ArrayList<>();
    private Context context;

    public IngridientViewPagerAdapter(FragmentManager fragmentManager) {
        super(fragmentManager);
    }

    // Returns total number of pages
    @Override
    public int getCount() {
        return fragmentsList.size();
    }

    public static void setPos(int pos) {

        IngridientViewPagerAdapter.pos = pos;

    }
    public static int getPos() {

        return pos;

    }

    @Override
    public Fragment getItem(int position) {

        return fragmentsList.get(position);

    }

    @Nullable
    @Override
    public CharSequence getPageTitle(int position) {
        if(fragmentsList.get(position) instanceof Ingredient_List_Fragment) {
            Ingredient_List_Fragment f = (Ingredient_List_Fragment) fragmentsList.get(position);
            return f.getIngList().getName();
        }
        return super.getPageTitle(position);
    }

    @Override
    public int getItemPosition(@NonNull Object object) {
        return POSITION_NONE;
    }

    public ArrayList<Fragment> getAllLists (){

        return fragmentsList;

    }

    public void addFragment(Fragment fragment) {

        fragmentsList.add(fragment);

    }

    public void addList(ArrayList<Fragment> fragments) {

        fragmentsList.clear();
        fragmentsList.addAll(fragments);

    }
}


