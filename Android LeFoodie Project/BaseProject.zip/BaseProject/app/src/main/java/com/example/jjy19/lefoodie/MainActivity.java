package com.example.jjy19.lefoodie;
import android.arch.lifecycle.LiveData;
import android.arch.lifecycle.Observer;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.ServiceConnection;
import android.os.Bundle;
import android.os.IBinder;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.design.widget.FloatingActionButton;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.view.ViewPager;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Toast;
import com.example.jjy19.lefoodie.Database.Repository;
import com.example.jjy19.lefoodie.Database.SharedPreferenceHelper;
import com.example.jjy19.lefoodie.MainActivityFragments.Add_Ingredient;
import com.example.jjy19.lefoodie.MainActivityFragments.Add_Ingredient_List;
import com.example.jjy19.lefoodie.MainActivityFragments.Edit_Ingredient;
import com.example.jjy19.lefoodie.MainActivityFragments.Ingredient_List_Fragment;
import com.example.jjy19.lefoodie.MainActivityFragments.IngridientViewPagerAdapter;
import com.example.jjy19.lefoodie.Models.Ingredient;
import com.example.jjy19.lefoodie.Models.IngredientList;
import com.example.jjy19.lefoodie.Models.User;
import com.firebase.ui.auth.AuthUI;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.example.jjy19.lefoodie.Services.IngredientService;
import java.util.List;

import java.util.ArrayList;
import java.util.Arrays;

public class MainActivity extends AppCompatActivity implements Ingredient_List_Fragment.OnListFragmentInteractionListener, Add_Ingredient.IOnAddIngredient, Edit_Ingredient.IOnEditIngredient, Add_Ingredient_List.OnFragmentInteractionListener {
    private static final String TAG = "MainActivity";
    private Repository repository;
    static IngridientViewPagerAdapter adapterViewPager;
    private Add_Ingredient addIngredientFragment;
    private ViewPager vpPager;
    private List<Ingredient> selectedIngredients;
    private IngredientService ingredientService;
    private ServiceConnection mConnection;

    public static List<IngredientList> myList;

    Fragment ingredientList;
    ArrayList<Fragment> fragments;
    FloatingActionButton fab;

    LiveData<List<IngredientList>> liveList;
    listObserver lObserver;

    // AUTHENTICATION
    private FirebaseAuth auth;
    private FirebaseAuth.AuthStateListener authListener;
    private final int REQUEST_SIGN_IN = 1101;

    // Shared Preferences - Used for keeping track of login
    SharedPreferenceHelper spHelper;

    @Override
    protected void onDestroy() {
        super.onDestroy();
        unbindService(mConnection);
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        // Shared Preference
        spHelper = new SharedPreferenceHelper( getSharedPreferences(SharedPreferenceHelper.SharedPrefName, MODE_PRIVATE));

        // AUTH
        // Inspired by Udacity firebase weekend course
        auth = FirebaseAuth.getInstance();
        authListener = new FirebaseAuth.AuthStateListener() {
            @Override
            public void onAuthStateChanged(@NonNull FirebaseAuth firebaseAuth) {
                FirebaseUser user = firebaseAuth.getCurrentUser();

                if(user != null){

                    // Check if anonymous - This is offline
                    if(user.isAnonymous()){
                        spHelper.setSync(false);
                        repository.changeSync(false, liveList.getValue());
                    }
                    else{
                        String photo = user.getPhotoUrl() == null ? "" : user.getPhotoUrl().toString();
                        User newUser = new User(user.getDisplayName(), user.getEmail(), photo, false);

                        spHelper.setUser(newUser);
                        spHelper.setSync(true);

                        liveList.removeObserver(lObserver);
                        fragments.clear();
                        repository.changeSync(true, liveList.getValue());

                        liveList = repository.getAll();
                        lObserver = new listObserver();
                        liveList.observe(MainActivity.this, lObserver);
                    }
                }
                else{
                    // Sign in
                    startActivityForResult(
                            AuthUI.getInstance()
                                    .createSignInIntentBuilder()
                                    .setAvailableProviders(Arrays.asList(
                                            new AuthUI.IdpConfig.GoogleBuilder().build(),
                                            new AuthUI.IdpConfig.EmailBuilder().build(),
                                            new AuthUI.IdpConfig.AnonymousBuilder().build()))
                                    .build(),
                            REQUEST_SIGN_IN);
                }
            }
        };

        // REPO CONNECTION
        repository = new Repository(MainActivity.this);

        // Create a new empty list for selected ingredients
        selectedIngredients = new ArrayList<Ingredient>();

        // create multiple ingredient lists
        fragments = new ArrayList<Fragment>();

        // setup viewPager
        vpPager = findViewById(R.id.pager);
        adapterViewPager = new IngridientViewPagerAdapter(MainActivity.this.getSupportFragmentManager());

        vpPager.setAdapter(adapterViewPager);

        liveList = repository.getAll();
        lObserver = new listObserver();
        liveList.observe(this, lObserver);

        if(repository.getAllIngredientNames().size() < 1) {
            addIngredientListFragment();
        }

        fab = findViewById(R.id.fab);
        fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(selectedIngredients.size() < 1) {
                    addIngredientDialog();
                } else {
                    openRecipeActivity();
                }
            }
        });

        Intent serviceIntent = new Intent(this, IngredientService.class);

        // Start background service
        startService(serviceIntent);

        // Bind to service
        this.connectToRecipeService(serviceIntent);
    }

    private void connectToRecipeService(Intent intent){
        Log.i(TAG, "\n\nBinding to service");

        mConnection = new ServiceConnection() {
            @Override
            public void onServiceConnected(ComponentName name, IBinder service) {
                ingredientService = ((IngredientService.RecipeServiceBinder)service).getService();
            }

            @Override
            public void onServiceDisconnected(ComponentName name) {
                ingredientService = null;
            }
        };
        bindService(intent, mConnection, Context.BIND_NOT_FOREGROUND);
    }

    @Override
    protected void onResume() {
        super.onResume();
        auth.addAuthStateListener(authListener);
    }

    @Override
    protected void onPause() {
        super.onPause();
        auth.removeAuthStateListener(authListener);
    }

    private void addIngredientListFragment(){
        Fragment fragment = new Add_Ingredient_List();
        fragments.add(fragment);
        adapterViewPager.addList(fragments);
        adapterViewPager.notifyDataSetChanged();
    }

    private void openRecipeActivity(){
        if(selectedIngredients.size() > 5){
            toastMaker(getResources().getString(R.string.IngredientCap));
        } else {
            String ingredients = "";
            for(int i = 0; i!=selectedIngredients.size(); i++){
                Ingredient ing = selectedIngredients.get(i);
                ingredients = ingredients + ing.getName()+",";
            }
            Intent intent = new Intent(MainActivity.this, RecipeListActivity.class);
            intent.putExtra("IngredientNames", ingredients);
            startActivityForResult(intent, 299);
        }
    }

    private void addIngredientDialog() {
        // get current position
        int position = vpPager.getCurrentItem();
        // get fragment which belongs to current position
        Fragment ingredientFragment = adapterViewPager.getItem(position);
        // get the current ingredient list in said fragment
        try {
            IngredientList currentList = ((Ingredient_List_Fragment) ingredientFragment).getIngList();
            // Create fragment manager
            FragmentManager fm = getSupportFragmentManager();
            // Create add ingredient fragment
            addIngredientFragment = new Add_Ingredient();
            // set the ingredient list to add ingredient fragment
            addIngredientFragment.setTargetIngredientList(currentList);
            // show fragment
            addIngredientFragment.show(fm, "Add_Ingredient_Fragment");
        } catch(Exception e){
            toastMaker(getResources().getString(R.string.add_on_wrong_fragment));
        }
    }



    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_main, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_signout) {
            AuthUI.getInstance().signOut(this);
            return true;
        }

        return super.onOptionsItemSelected(item);
    }

    @Override
    public void onListFragmentInteraction(Ingredient item, IngredientList list, Boolean add) {
        if(add){
            selectedIngredients.add(item);
        } else {
            selectedIngredients.remove(item);
        }
        if(selectedIngredients.size() == 0){
            fab.setImageResource(R.drawable.ic_add_black_24dp);
        } else {
            fab.setImageResource(R.drawable.ic_search_black_24dp);
        }
    }

    private void toastMaker(String message){
        Log.i(TAG, message);
        Toast.makeText(this, message, Toast.LENGTH_LONG).show();
    }

    @Override
    public void onAddIngredient(Ingredient ingredient, IngredientList list) {
        repository.insertIngredient(ingredient, list);
        addIngredientFragment.dismiss();
        toastMaker(ingredient.getName() + " " + getResources().getString(R.string.add_to_db));
    }

    @Override
    public void onEditIngredient(Ingredient ingredient, IngredientList list) {
        repository.updateIngredient(ingredient, list);
        addIngredientFragment.dismiss();
        toastMaker(ingredient.getName() + " " + getResources().getString(R.string.add_to_db));
    }

    @Override
    public void onFragmentInteraction(IngredientList list) {
        repository.createNewList(list.getName(), list.getSharable());
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {

        switch (requestCode){
            case REQUEST_SIGN_IN:
                if(resultCode == RESULT_CANCELED){
                    // User is trying to exit
                    finish();
                }
                break;
            default:
                Log.e("MainActivityOnResult", "Got request code not specified");
        }
    }

    // OBSERVER FOR LIVEDATA
    private class listObserver implements Observer<List<IngredientList>> {

        @Override
        public void onChanged(@Nullable List<IngredientList> lists) {
            fragments.clear();
            for(int i = 0; i<lists.size(); i++) {
                ingredientList = new Ingredient_List_Fragment();
                ((Ingredient_List_Fragment) ingredientList).setIngLists(lists.get(i));
                fragments.add(ingredientList);
                (adapterViewPager).addList(fragments);
            }
            addIngredientListFragment();
        }
    }
}
