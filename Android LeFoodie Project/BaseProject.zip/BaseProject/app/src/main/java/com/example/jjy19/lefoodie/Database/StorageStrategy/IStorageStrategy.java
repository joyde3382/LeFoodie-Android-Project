package com.example.jjy19.lefoodie.Database.StorageStrategy;

import android.arch.lifecycle.LiveData;

import com.example.jjy19.lefoodie.Models.Ingredient;
import com.example.jjy19.lefoodie.Models.IngredientList;

import java.util.List;

public interface IStorageStrategy {
    LiveData<List<IngredientList>> getAll();

    IngredientList getIngredientList(int id);

    void saveList(IngredientList newList);

    void insertListsWhenChaningSync(List<IngredientList> lists);

    void updateIngredient(Ingredient ingredient, IngredientList list);

    List<String> getAllIngredientNames();

    void insertIngredient(Ingredient ingredient, IngredientList list);

    void updateList(IngredientList list);

    void deleteList(IngredientList list);
}
