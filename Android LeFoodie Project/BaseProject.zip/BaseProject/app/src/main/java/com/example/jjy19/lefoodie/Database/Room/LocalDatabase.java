package com.example.jjy19.lefoodie.Database.Room;

// Inspiration for singleton and onCreate population from:
// https://android.jlelse.eu/pre-populate-room-database-6920f9acc870

import android.arch.persistence.db.SupportSQLiteDatabase;
import android.arch.persistence.room.Database;
import android.arch.persistence.room.Room;
import android.arch.persistence.room.RoomDatabase;
import android.arch.persistence.room.TypeConverters;
import android.content.Context;
import android.content.Intent;
import android.support.annotation.NonNull;
import android.support.v4.content.LocalBroadcastManager;

import com.example.jjy19.lefoodie.Models.Ingredient;
import com.example.jjy19.lefoodie.Models.IngredientList;
import com.example.jjy19.lefoodie.Models.User;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.concurrent.Executors;

@Database(entities = {IngredientList.class, Ingredient.class}, version = 1, exportSchema = false)
@TypeConverters(Converters.class)
public abstract class LocalDatabase extends RoomDatabase {

    public abstract IngredientListDAO ingredientListDAO();

    private final static String databaseName = "com.example.jjy19.lefoodie.db";

    // Singleton
    private static LocalDatabase INSTANCE;
    public static  LocalDatabase getInstance(Context context){
        if(INSTANCE == null){
            INSTANCE = buildDB(context);
        }

        return INSTANCE;
    }

    // Building database
    private synchronized static LocalDatabase buildDB(final Context context){
        return Room.databaseBuilder(context.getApplicationContext(), LocalDatabase.class, databaseName)
                .fallbackToDestructiveMigration()
                .addCallback( new RoomDatabase.Callback(){
                    @Override
                    public void onCreate(@NonNull SupportSQLiteDatabase db) {
                        super.onCreate(db);

                        Executors.newSingleThreadExecutor().execute(new Runnable() {
                            @Override
                            public void run() {
                                IngredientListDAO dao = getInstance(context).ingredientListDAO();
                                generateList(dao);
                            }
                        });
                    }
                })
                .build();
    }

    public static void generateList(IngredientListDAO dao){
        List<Ingredient> ingedients = new ArrayList<Ingredient>();

        IngredientList ingredientList = new IngredientList("Kitchen", false);
        ingredientList.setIngredients(ingedients);
        ingredientList.uid = 1;

        dao.saveIngredientList(ingredientList);

        // Simulating userinput, so these strings should not be put in resources
        ingedients.add(new Ingredient("Rice", false, new Date(System.currentTimeMillis() + 24*60*60*1000), 1));
        ingedients.add(new Ingredient("Chicken", false, new Date(System.currentTimeMillis() + 24*60*60*1000), 1));
        ingedients.add(new Ingredient("Potato", false, new Date(System.currentTimeMillis() + 24*60*60*1000), 1));
        ingedients.add(new Ingredient("Honey", false, new Date(System.currentTimeMillis() - 24*60*60*1000),1));
        ingedients.add(new Ingredient("Tomato", false, new Date(System.currentTimeMillis() - 24*60*60*1000),1));
        ingedients.add(new Ingredient("Cucumber", false, new Date(System.currentTimeMillis() + 24*60*60*1000),1));
        ingedients.add(new Ingredient("Salmon", false, new Date(System.currentTimeMillis() + 24*60*60*1000),1));
        ingedients.add(new Ingredient("Salad", false, new Date(System.currentTimeMillis() + 24*60*60*1000),1));
        ingedients.add(new Ingredient("Bread", false, new Date(System.currentTimeMillis() + 24*60*60*1000),1));

        dao.saveIngredients(ingedients);

        List<Ingredient> ingedients2 = new ArrayList<Ingredient>();
        IngredientList ingredientList2 = new IngredientList("ButcherHouse", false);
        ingredientList2.setIngredients(ingedients2);
        ingredientList2.uid = 2;

        dao.saveIngredientList(ingredientList2);

        // Simulating userinput, so these strings should not be put in resources
        ingedients2.add(new Ingredient("Beef", false, new Date(System.currentTimeMillis() + 24*60*60*1000), 2));
        ingedients2.add(new Ingredient("Pork", false, new Date(System.currentTimeMillis() + 24*60*60*1000), 2));
        ingedients2.add(new Ingredient("Loin", false, new Date(System.currentTimeMillis() + 24*60*60*1000), 2));
        ingedients2.add(new Ingredient("Potato", false, new Date(System.currentTimeMillis() - 24*60*60*1000),2));
        ingedients2.add(new Ingredient("Tomato", false, new Date(System.currentTimeMillis() - 24*60*60*1000),2));

        dao.saveIngredients(ingedients2);
    }
}
