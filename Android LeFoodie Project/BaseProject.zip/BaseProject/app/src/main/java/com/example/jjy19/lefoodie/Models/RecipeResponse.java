package com.example.jjy19.lefoodie.Models;

import java.util.List;

public class RecipeResponse {
    public List<HitsResponse> getHits() {
        return hits;
    }

    public void setHits(List<HitsResponse> hits) {
        this.hits = hits;
    }

    public RecipeResponse(List<HitsResponse> hits) {
        this.hits = hits;
    }

    public List<HitsResponse> hits;
}

