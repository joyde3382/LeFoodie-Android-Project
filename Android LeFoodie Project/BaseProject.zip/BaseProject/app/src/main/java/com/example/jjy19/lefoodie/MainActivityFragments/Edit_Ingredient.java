package com.example.jjy19.lefoodie.MainActivityFragments;

import android.app.DatePickerDialog;
import android.content.Context;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.DialogFragment;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;

import com.example.jjy19.lefoodie.Database.Repository;
import com.example.jjy19.lefoodie.Models.Ingredient;
import com.example.jjy19.lefoodie.Models.IngredientList;
import com.example.jjy19.lefoodie.R;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

public class Edit_Ingredient extends DialogFragment {

    public interface IOnEditIngredient {
        void onEditIngredient(Ingredient ingredient, IngredientList list);
    }

    public IngredientList getTargetIngredientList() {
        return targetIngredientList;
    }

    public void setTargetIngredientList(IngredientList targetIngredientList) {
        this.targetIngredientList = targetIngredientList;
    }

    IngredientList targetIngredientList;

    private Edit_Ingredient.IOnEditIngredient onFormFilled;
    Repository repo;
    private static String TAG = "EDIT_INGREDIENT_FRAGMENT";

    // Buttons and widgets
    Button saveIngredientBtn;
    EditText ingredientName;
    EditText ingredientExpDate;
    DatePickerDialog.OnDateSetListener date;
    Calendar myCalendar = Calendar.getInstance();
    SimpleDateFormat dateFormatter = new SimpleDateFormat("dd/MM/yyyy");

    public Edit_Ingredient() {}

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view = inflater.inflate(R.layout.fragment_edit_ingredient, container, false);



        repo = new Repository(getContext());
        // Get both input fields and the buttons
        ingredientName = view.findViewById(R.id.edit_Ingredient_Name_Holder);
        ingredientExpDate = view.findViewById(R.id.edit_Ingredient_Expiration_Holder);
        saveIngredientBtn = view.findViewById(R.id.Edit_Ingredient_Edit_Btn);

        // Calendar popup
        date = new DatePickerDialog.OnDateSetListener() {

            @Override
            public void onDateSet(DatePicker view, int year, int monthOfYear,
                                  int dayOfMonth) {
                myCalendar.set(year, monthOfYear, dayOfMonth);
                Date selectedDate = myCalendar.getTime();
                ingredientExpDate.setText(dateFormatter.format(selectedDate));
            }

        };

        ingredientExpDate.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                new DatePickerDialog((getActivity()), date, myCalendar
                        .get(Calendar.YEAR), myCalendar.get(Calendar.MONTH),
                        myCalendar.get(Calendar.DAY_OF_MONTH)).show();
            }
        });

        // On save click
        saveIngredientBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // If there is a text in both ingredient and exp date.
                if(!ingredientName.getText().toString().equals("") && !ingredientExpDate.getText().toString().equals("")) {

                    Bundle mArgs = getArguments();
                    Ingredient ingredientUpdate = (Ingredient) mArgs.getSerializable("EditIngredient");

                    ingredientUpdate.setName(ingredientName.getText().toString());
                    ingredientUpdate.setExperiation(myCalendar.getTime());

                    IngredientList list = repo.getIngredientList(ingredientUpdate.getListId());

                    repo.updateIngredient(ingredientUpdate, list);


                    Edit_Ingredient.this.dismiss();

                } else
                {
                    ingredientName.setError(getResources().getString(R.string.title_error));
                }
            }
        });

        return view;
    }

    public void onAttach(Context context) {
        super.onAttach(context);
        try{
            onFormFilled = (Edit_Ingredient.IOnEditIngredient) getActivity();
        } catch (Exception e){
            Log.e(TAG, e.toString());
        }
    }

    @Override
    public void onDetach() {
        super.onDetach();
        onFormFilled = null;
    }
}
