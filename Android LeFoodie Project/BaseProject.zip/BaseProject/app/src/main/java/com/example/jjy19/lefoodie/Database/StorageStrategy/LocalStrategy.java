package com.example.jjy19.lefoodie.Database.StorageStrategy;

import android.arch.core.util.Function;
import android.arch.lifecycle.LiveData;
import android.arch.lifecycle.MediatorLiveData;
import android.arch.lifecycle.Observer;
import android.arch.lifecycle.Transformations;
import android.content.Context;
import android.support.annotation.Nullable;

import com.example.jjy19.lefoodie.Database.Room.IngredientListDAO;
import com.example.jjy19.lefoodie.Database.Room.LocalDatabase;
import com.example.jjy19.lefoodie.Models.Ingredient;
import com.example.jjy19.lefoodie.Models.IngredientList;

import java.util.List;

public class LocalStrategy implements IStorageStrategy {

    private IngredientListDAO dao_;
    private LocalDatabase db_;

    public LocalStrategy(Context context){
        db_ = LocalDatabase.getInstance(context);
        dao_ = db_.ingredientListDAO();
    }

    @Override
    public LiveData<List<IngredientList>> getAll() {
        LiveData<List<IngredientList>> lists = dao_.getAll();

        lists = Transformations.switchMap(lists, new Function<List<IngredientList>, LiveData<List<IngredientList>>>(){

            @Override
            public LiveData<List<IngredientList>> apply(final List<IngredientList> input) {
                final MediatorLiveData<List<IngredientList>> listMediator = new MediatorLiveData<>();

                for(final IngredientList list : input){
                    listMediator.addSource(dao_.getIngredientsOnList(list.uid), new Observer<List<Ingredient>>() {
                        @Override
                        public void onChanged(@Nullable List<Ingredient> ingredients) {
                            list.setIngredients(ingredients);
                            listMediator.postValue(input);
                        }
                    });
                }

                return listMediator;
            }
        });

        return lists;
    }

    @Override
    public IngredientList getIngredientList(int id) {
        IngredientList list = dao_.getIngredientList(id);

        // This would be used if it was live data
        //list = Transformations.switchMap(list, new Function<IngredientList, LiveData<IngredientList>>() {
        //    @Override
        //    public LiveData<IngredientList> apply(final IngredientList inputList) {
        //        LiveData<List<Ingredient>> ingredients = dao_.getIngredientsOnList(inputList.uid);
        //        LiveData<IngredientList> output = Transformations.map(ingredients, new Function<List<Ingredient>, IngredientList>() {
        //            @Override
        //            public IngredientList apply(List<Ingredient> inputIngredients) {
        //                inputList.setIngredients(inputIngredients);
        //                return inputList;
        //            }
        //        });
        //        return output;
        //    }
        //});

        return list;
    }

    @Override
    public void saveList(IngredientList newList) {
        dao_.saveIngredients(newList.getIngredients());
        dao_.saveIngredientList(newList);
    }

    @Override
    public void insertListsWhenChaningSync(List<IngredientList> lists) {
        // Clear whole db, since we want a perfect copy from the web
        db_.clearAllTables();

        for(IngredientList list : lists){
            dao_.saveIngredients(list.getIngredients());
        }

        dao_.saveIngredientLists(lists);
    }

    @Override
    public void updateIngredient(Ingredient ingredient, IngredientList list) { dao_.updateIngredient(ingredient); }

    @Override
    public List<String> getAllIngredientNames() { return dao_.getAllIngredientNames(); }

    @Override
    public void insertIngredient(Ingredient ingredient, IngredientList list) { dao_.saveIngredient(ingredient); }

    @Override
    public void updateList(IngredientList list) { dao_.saveIngredientList(list); }

    @Override
    public void deleteList(IngredientList list) { dao_.deleteIngredientList(list); }
}
