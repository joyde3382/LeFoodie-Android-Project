package com.example.jjy19.lefoodie.Database.StorageStrategy;

import android.arch.lifecycle.LiveData;
import android.arch.lifecycle.MutableLiveData;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.util.Log;

import com.example.jjy19.lefoodie.Models.Ingredient;
import com.example.jjy19.lefoodie.Models.IngredientList;
import com.google.firebase.database.ChildEventListener;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

import java.util.ArrayList;
import java.util.List;

// Firebase database knowhow from Udacity's firebase weekend course

public class CloudStrategy implements IStorageStrategy {
    private final String TAG = "CloudStrategy";

    // FIELDS
    private FirebaseDatabase db_;
    private DatabaseReference dbr_;
    private final String DATABASE_CHILD = "ingredientLists";

    private ChildEventListener ingredientListListener_;

    List<IngredientList> ingredientLists_;
    MutableLiveData<List<IngredientList>> liveLists_;

    public CloudStrategy(){
        ingredientLists_ = new ArrayList<>();
        liveLists_ = new MutableLiveData<>();

        db_ = FirebaseDatabase.getInstance();
        dbr_ = db_.getReference().child(DATABASE_CHILD);

        ingredientListListener_ = new ChildEventListener() {
            @Override
            public void onChildAdded(@NonNull DataSnapshot dataSnapshot, @Nullable String s) {
                ingredientLists_.add( dataSnapshot.getValue( IngredientList.class) );
                liveLists_.setValue(ingredientLists_);
            }

            @Override
            public void onChildChanged(@NonNull DataSnapshot dataSnapshot, @Nullable String s) {
                IngredientList tmp = dataSnapshot.getValue( IngredientList.class );

                int i = 0;
                // Ugly, but works?
                for(IngredientList list : ingredientLists_){
                    if(list.uid == tmp.uid){
                        ingredientLists_.set(i, tmp);
                    }
                    i++;
                }

                liveLists_.setValue(ingredientLists_);
            }

            @Override
            public void onChildRemoved(@NonNull DataSnapshot dataSnapshot) {

                if(ingredientLists_.remove( dataSnapshot.getValue( IngredientList.class ))){
                    liveLists_.setValue(ingredientLists_);
                }
            }

            @Override
            public void onChildMoved(@NonNull DataSnapshot dataSnapshot, @Nullable String s) {
                // Wont happen
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {
                //TODO HOW TO HANDLE ERRORS?
                Log.e(TAG, "Firebase encountered error: " + databaseError.getMessage());
            }
        };

        dbr_.addChildEventListener(ingredientListListener_);
    }

    @Override
    public LiveData<List<IngredientList>> getAll() {
        return liveLists_;
    }

    @Override
    public IngredientList getIngredientList(int id) {
        for(IngredientList i : ingredientLists_){
            if(i.uid == id){
                // Don't think this will be actively updated
                // But I don't think it needs to.
                return i;
            }
        }
        return null;
    }

    @Override
    public void saveList(IngredientList newList) {
        // TODO Better way of managing ids
        int newId = ingredientLists_.get(ingredientLists_.size() - 1).uid + 1;
        newList.uid = newId;
        dbr_.child(String.valueOf(newId)).setValue(newList);
    }

    @Override
    public void insertListsWhenChaningSync(List<IngredientList> lists) {
        // Remove any lists that are dublicates of offline lists
        for(IngredientList i : lists){
            // Not removed, since we don't handle userspecific lists yet..
            // dbr_.child(String.valueOf(i.uid)).removeValue();
            dbr_.child(String.valueOf(i.uid)).setValue(i);
        }
    }

    @Override
    public void updateIngredient(Ingredient ingredient, IngredientList list) {
        int i = 0;
        for(Ingredient ing : list.getIngredients()){
            if(ing.getName().equals( ingredient.getName() )){
                list.getIngredients().set(i, ingredient);
            }
            i++;
        }
        updateList(list);
    }

    @Override
    public List<String> getAllIngredientNames() {
        List<String> names = new ArrayList<>();

        for(IngredientList list : ingredientLists_){
            for(Ingredient i : list.getIngredients() ){
                names.add(i.getName());
            }
        }

        return names;
    }

    @Override
    public void insertIngredient(Ingredient ingredient, IngredientList list) {
        List<Ingredient> tmp = list.getIngredients();

        list.getIngredients().add(ingredient);

        dbr_.child(String.valueOf(list.uid)).setValue(list);
    }

    @Override
    public void updateList(IngredientList list) {
        dbr_.child(String.valueOf(list.uid)).setValue(list);
    }

    @Override
    public void deleteList(IngredientList list) {
        dbr_.child(String.valueOf(list.uid)).removeValue();
    }
}
