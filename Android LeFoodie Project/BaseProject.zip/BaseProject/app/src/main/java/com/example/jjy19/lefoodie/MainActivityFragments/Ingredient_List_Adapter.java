package com.example.jjy19.lefoodie.MainActivityFragments;

import android.graphics.Color;
import android.graphics.ColorFilter;
import android.support.v7.widget.RecyclerView;
import android.view.ContextMenu;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.CheckBox;
import android.widget.TextView;

import com.example.jjy19.lefoodie.MainActivityFragments.Ingredient_List_Fragment.OnListFragmentInteractionListener;
import com.example.jjy19.lefoodie.Models.Ingredient;
import com.example.jjy19.lefoodie.Models.IngredientList;
import com.example.jjy19.lefoodie.R;
import com.firebase.ui.auth.data.model.Resource;

import java.text.SimpleDateFormat;

public class Ingredient_List_Adapter extends RecyclerView.Adapter<Ingredient_List_Adapter.ViewHolder> {
    private static final String TAG = "INGREDIENT_LIST_ADAPTER";
    private final IngredientList myList;
    private final OnListFragmentInteractionListener myListener;
    ColorFilter test;
    public Ingredient_List_Adapter(IngredientList list, OnListFragmentInteractionListener listener) {
        myList = list;
        myListener = listener;
    }

    @Override
    public ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.fragment_ingredient_list, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(final ViewHolder holder, final int position) {
        holder.mItem = myList.getIngredients().get(position);
        if(!holder.mItem.isDeleted()) {
            if (holder.mItem.isLow()) {
                holder.mView.setBackgroundColor(Color.rgb(147, 157, 173));
            }
            else {
                holder.mView.setBackgroundColor(Color.rgb(250, 250, 250));
            }
            final SimpleDateFormat format = new SimpleDateFormat("dd/MM/yyyy");
            holder.mIngredientName.setText(myList.getIngredients().get(position).getName());
            holder.mIngredientExpiration.setText(format.format(myList.getIngredients().get(position).getExperiation()));
            holder.mIngredientCheckBox.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    if (holder.mIngredientCheckBox.isChecked()) {
                        myListener.onListFragmentInteraction(holder.mItem, myList, true);
                    } else {
                        myListener.onListFragmentInteraction(holder.mItem, myList, false);
                    }
                }
            });
        } else{
            holder.mView.setVisibility(View.GONE);
            holder.mView.setLayoutParams(new RecyclerView.LayoutParams(0, 0));
        }
    }

    @Override
    public int getItemCount() {
        return myList.getIngredients().size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder  implements View.OnCreateContextMenuListener {
        public final View mView;
        public final TextView mIngredientName;
        public final TextView mIngredientExpiration;
        public final CheckBox mIngredientCheckBox;
        public Ingredient mItem;

        public ViewHolder(View view) {
            super(view);
            mView = view;
            mIngredientName = view.findViewById(R.id.Fragment_List_Ingredient_Name);
            mIngredientExpiration = view.findViewById(R.id.Fragment_List_Ingredient_Expiration);
            mIngredientCheckBox = view.findViewById(R.id.Fragment_List_ingredient_Select);
            mView.setOnCreateContextMenuListener(this);
        }

        @Override
        public void onCreateContextMenu(ContextMenu menu, View v, ContextMenu.ContextMenuInfo menuInfo) {
            menu.add(this.getAdapterPosition(),121,0,v.getContext().getResources().getString(R.string.context_edit));
            menu.add(this.getAdapterPosition(),122,1,v.getContext().getResources().getString(R.string.context_flaglow));
            menu.add(this.getAdapterPosition(),123,2,v.getContext().getResources().getString(R.string.context_restock));
            menu.add(this.getAdapterPosition(),124,3,v.getContext().getResources().getString(R.string.context_delete));
        }
    }

}
