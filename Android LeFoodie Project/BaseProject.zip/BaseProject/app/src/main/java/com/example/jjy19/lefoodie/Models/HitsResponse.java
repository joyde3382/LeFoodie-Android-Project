package com.example.jjy19.lefoodie.Models;

import com.example.jjy19.lefoodie.Models.Recipe;

public class HitsResponse {
    public Recipe getRecipe() {
        return recipe;
    }

    public void setRecipe(Recipe recipe) {
        this.recipe = recipe;
    }

    public Recipe recipe;

    public HitsResponse(Recipe recipe) {
        this.recipe = recipe;
    }
}