package com.example.jjy19.lefoodie.Models;

import android.arch.persistence.room.Entity;
import android.arch.persistence.room.ForeignKey;
import android.arch.persistence.room.PrimaryKey;
import android.arch.persistence.room.TypeConverter;

import java.io.Serializable;
import java.util.Date;

@Entity
public class Ingredient implements Serializable {

    @PrimaryKey(autoGenerate = true)
    private int id;
    private String Name;
    private boolean low;
    private Date experiation;
    private boolean deleted;

    // Foreign for room
    @ForeignKey(entity = IngredientList.class, parentColumns = "uid", childColumns = "listId")
    private int listId;

    // CONSTRUCTION
    public Ingredient(){}   // Needed for room

    public Ingredient(String name, boolean low, Date experiation) {
        this.Name = name;
        this.low = low;
        this.experiation = experiation;
        this.deleted = false;
    }

    public Ingredient(String name, boolean low, Date experiation, int listid){
        this(name, low, experiation);
        this.listId = listid;
    }

    // GET AND SET
    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getName() {
        return Name;
    }

    public void setName(String name) {
        Name = name;
    }

    public boolean isLow() {
        return low;
    }

    public void setLow(boolean low) {
        this.low = low;
    }

    public Date getExperiation() {
        return experiation;
    }

    public void setExperiation(Date experiation) {
        this.experiation = experiation;
    }

    public int getListId() { return listId; }

    public void setListId(int listId) { this.listId = listId; }

    public boolean isDeleted() { return deleted; }

    public void setDeleted(boolean deleted) { this.deleted = deleted; }
}
