package com.example.jjy19.lefoodie;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.View;
import android.widget.ProgressBar;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.example.jjy19.lefoodie.Models.Recipe;
import com.example.jjy19.lefoodie.Models.RecipeResponse;
import com.example.jjy19.lefoodie.Models.HitsResponse;
import com.example.jjy19.lefoodie.RecipeListFragments.RecipeFragment;

import com.example.jjy19.lefoodie.RecipeListFragments.webviewFragment;
import com.google.gson.Gson;

import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

public class RecipeListActivity extends AppCompatActivity implements RecipeFragment.OnListFragmentInteractionListener, webviewFragment.OnFragmentInteractionListener {
    private static final String TAG = "Recipe-Activity";
    private static final String AppID = "1948f7c6";
    private static final String AppKey = "0fc1fd6e9c207cf46982cfdc405da0a6";
    String requestedIngredients;
    RequestQueue myRequestQueue;
    List<Recipe> suggestedRecipes;

    // Spinner
    ProgressBar spinner;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_recipe_list);

        spinner = findViewById(R.id.loadingRecipes);
        spinner.setVisibility(View.VISIBLE);

        Intent detailsIntent = getIntent();
        requestedIngredients = detailsIntent.getStringExtra("IngredientNames");
        suggestedRecipes = new ArrayList<>();
        getRecipes();
    }

    private List<Recipe> getRecipeList(JSONObject obj){
        return null;
    }

    public void getRecipes(){
        String url = "https://api.edamam.com/search?q="+requestedIngredients+"&app_id=" + AppID + "&app_key="+AppKey;
        myRequestQueue = Volley.newRequestQueue(this);
        StringRequest request = new StringRequest(Request.Method.GET, url, new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {
                Gson googleJson = new Gson();

                // Get recipes
                RecipeResponse responseObj = googleJson.fromJson(response, RecipeResponse.class);

                // Add recipes
                for(int i = 0; i!=responseObj.hits.size(); i++){
                    HitsResponse res = responseObj.hits.get(i);
                    suggestedRecipes.add(res.recipe);
                }

                // Stop spinner
                spinner.setVisibility(View.INVISIBLE);

                //Activate fragment
                switchFragment(new RecipeFragment());
            }
        }, new Response.ErrorListener(){
            @Override
            public void onErrorResponse(VolleyError error) {
                Log.i(TAG, "Error fetching recipes");
            }
        });
        myRequestQueue.add(request);
    }

    public void switchFragment(RecipeFragment fragment) {
        fragment.setSuggestedRecipes(suggestedRecipes);
        FragmentManager fragmentManager = getSupportFragmentManager();
        fragmentManager.beginTransaction()
                .replace(R.id.fragmentHolder, fragment)
                .commit();
    }

    public void showWebview(webviewFragment fragment) {
        FragmentManager fragmentManager = getSupportFragmentManager();
        fragmentManager.beginTransaction()
                .replace(R.id.fragmentHolder, fragment)
                .commit();
    }

    @Override
    public void onListFragmentInteraction(Recipe item) {
        webviewFragment webview = new webviewFragment();
        (webview).setTargetRecipe(item);
        showWebview(webview);
    }

    @Override
    public void onFragmentInteraction(Uri uri) {

    }
}

