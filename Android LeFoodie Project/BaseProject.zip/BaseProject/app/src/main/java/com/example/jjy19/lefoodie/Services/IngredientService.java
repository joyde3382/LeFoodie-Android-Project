package com.example.jjy19.lefoodie.Services;

import android.app.AlarmManager;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.os.Binder;
import android.os.Build;
import android.os.IBinder;

import java.util.Calendar;

// Shouldn't really be named Recipe service - as it doesn't do shit with recipes
public class IngredientService extends Service {
    private static final String TAG = "Expiration service";
    private IBinder binder;
    PendingIntent myPendingIntent;
    AlarmManager alarmManager;

    public IngredientService() {
        binder = new RecipeServiceBinder();
    }

    @Override
    public void onCreate() {
        super.onCreate();
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        createNotificationChannel();
        registerServices();
        return START_STICKY;
    }

    private void registerServices()
    {
        Calendar cal = Calendar.getInstance();
        cal.set(Calendar.HOUR_OF_DAY, 0);
        cal.set(Calendar.MINUTE, 22);
        cal.set(Calendar.SECOND, 30);

        // Set the time to initiate repeat
        Intent deleteIntent = new Intent(getApplicationContext(), DeleteExpired.class);
        myPendingIntent = PendingIntent.getBroadcast( getApplicationContext(), 100, deleteIntent, PendingIntent.FLAG_CANCEL_CURRENT );
        alarmManager = (AlarmManager)(getApplicationContext().getSystemService( Context.ALARM_SERVICE ));
        alarmManager.setRepeating(AlarmManager.RTC_WAKEUP, cal.getTimeInMillis(), AlarmManager.INTERVAL_DAY, myPendingIntent);
    }

    public void createNotificationChannel() {
        NotificationChannel channel = null;
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            channel = new NotificationChannel("RecipeChannelId", "RecipeChannel", NotificationManager.IMPORTANCE_DEFAULT);
        }
        NotificationManager notificationManager = null;
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            notificationManager = getSystemService(NotificationManager.class);
        }
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            notificationManager.createNotificationChannel(channel);
        }
    }

    @Override
    public IBinder onBind(Intent intent) {
        return binder;
    }

    public class RecipeServiceBinder extends Binder {
        public IngredientService getService() {
            return IngredientService.this;
        }
    }
}
