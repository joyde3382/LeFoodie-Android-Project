package com.example.jjy19.lefoodie.Models;

import android.arch.persistence.room.Entity;
import android.arch.persistence.room.PrimaryKey;
import android.os.Parcel;
import android.os.Parcelable;

public class User {
    private String userName;
    private String userEmail;
    private String userPicture;
    private boolean anonymous;

    // CONSTRUCTION
    public User(String userName, String userEmail, String userPicture, boolean anonymous) {
        this.userName = userName;
        this.userPicture = userPicture;
        this.anonymous = anonymous;
        this.userEmail = userEmail;
    }

    public User(){}

    // GETTER SETTER
    public String getUserName() {
        return userName;
    }

    public void setUserName(String userName) {
        this.userName = userName;
    }

    public String getUserPicture() {
        return userPicture;
    }

    public void setUserPicture(String userPicture) {
        this.userPicture = userPicture;
    }

    public boolean isAnonymous() { return anonymous; }

    public void setAnonymous(boolean anonymous) { this.anonymous = anonymous; }

    public String getUserEmail() { return userEmail; }

    public void setUserEmail(String userEmail) { this.userEmail = userEmail; }

    @Override
    public boolean equals(Object obj) {
        if(obj instanceof User){
            User u = (User) obj;

            return this.userName == u.userName &&
                    this.userEmail == u.userEmail &&
                    this.userPicture == u.userPicture &&
                    this.anonymous == u.anonymous;
        }

        return false;
    }
}
