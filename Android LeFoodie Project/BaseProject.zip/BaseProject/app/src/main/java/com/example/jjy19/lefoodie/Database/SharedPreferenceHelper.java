package com.example.jjy19.lefoodie.Database;

import android.content.SharedPreferences;

import com.example.jjy19.lefoodie.Models.User;

public class SharedPreferenceHelper {
    // Tag - public
    public static final String SharedPrefName = "com.example.jjy19.lefoodie.sharedprefs";

    // User keys
    private static final String SPUserNameKey = "Username";
    private static final String SPUserEmailKey = "UserEmail";
    private static final String SPUserPictureKey = "UserPicture";
    private static final String SPUserAnonyKey = "UserAnony";

    // Syncing key
    private static final String SyncingKey = "Syncing";
    private static final String previousStateKey = "PreviousSync";

    // Variables
    SharedPreferences sp_;

    public SharedPreferenceHelper(SharedPreferences sp){
        sp_ = sp;
    }

    public User getUser(){
        return new User(
                sp_.getString(SPUserNameKey, ""),
                sp_.getString(SPUserEmailKey, ""),
                sp_.getString(SPUserPictureKey, ""),
                sp_.getBoolean(SPUserAnonyKey, true));
    }

    public void setUser(User user){
        SharedPreferences.Editor e = sp_.edit();
        e.putString(SPUserNameKey, user.getUserName());
        e.putString(SPUserEmailKey, user.getUserEmail());
        e.putString(SPUserPictureKey, user.getUserPicture());
        e.putBoolean(SPUserAnonyKey, user.isAnonymous());
        e.apply();
    }

    public boolean needsSync(){
        return sp_.getBoolean(SyncingKey, false);
    }

    public void setSync(boolean syncing){
        SharedPreferences.Editor e = sp_.edit();
        e.putBoolean(SyncingKey, syncing);
        e.apply();
    }

    public boolean previousSyncState(){ return sp_.getBoolean(previousStateKey, false); }

    public void setPreviousSyncState(boolean prevState){
        SharedPreferences.Editor e = sp_.edit();
        e.putBoolean(previousStateKey, prevState);
        e.apply();
    }
}
