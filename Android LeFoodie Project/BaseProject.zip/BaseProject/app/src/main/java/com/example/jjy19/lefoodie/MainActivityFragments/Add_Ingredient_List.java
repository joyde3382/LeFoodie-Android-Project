package com.example.jjy19.lefoodie.MainActivityFragments;

import android.content.Context;
import android.net.Uri;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.Toast;

import com.example.jjy19.lefoodie.Models.IngredientList;
import com.example.jjy19.lefoodie.R;

public class Add_Ingredient_List extends Fragment {
    private OnFragmentInteractionListener mListener;
    EditText title;
    CheckBox sharable;
    Button save;

    public Add_Ingredient_List() {}

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view = inflater.inflate(R.layout.fragment_add_ingredient_list, container, false);
        title = view.findViewById(R.id.add_ingredientList_title);
        sharable = view.findViewById(R.id.add_ingredientList_sharable);
        save = view.findViewById(R.id.add_ingredient_list_save);
        save.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(!title.getText().toString().equals("")) {
                    onButtonPressed(new IngredientList(title.getText().toString(), sharable.isChecked()));
                } else {
                    title.setError(getResources().getString(R.string.title_error));
                }
            }
        });
        return view;
    }

    public void onButtonPressed(IngredientList list) {
        if (mListener != null) {
            mListener.onFragmentInteraction(list);
        }
    }

    @Override
    public void onAttach(Context context) {
        super.onAttach(context);
        if (context instanceof OnFragmentInteractionListener) {
            mListener = (OnFragmentInteractionListener) context;
        } else {
            throw new RuntimeException(context.toString()
                    + " must implement OnFragmentInteractionListener");
        }
    }

    @Override
    public void onDetach() {
        super.onDetach();
        mListener = null;
    }

    public interface OnFragmentInteractionListener {
        void onFragmentInteraction(IngredientList list);
    }
}
