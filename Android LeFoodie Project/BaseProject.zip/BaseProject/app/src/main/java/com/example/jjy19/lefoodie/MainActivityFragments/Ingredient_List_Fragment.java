package com.example.jjy19.lefoodie.MainActivityFragments;

import android.content.Context;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v7.widget.GridLayoutManager;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import com.example.jjy19.lefoodie.Database.Repository;
import com.example.jjy19.lefoodie.Models.Ingredient;
import com.example.jjy19.lefoodie.Models.IngredientList;
import com.example.jjy19.lefoodie.R;

public class Ingredient_List_Fragment extends Fragment {
    private static final String ARG_COLUMN_COUNT = "column-count";
    private int mColumnCount = 1;
    private OnListFragmentInteractionListener mListener;
    RecyclerView recyclerView;
    public IngredientList getIngList() {
        return ingList;
    }
    public void setIngLists(IngredientList ingList) {
        this.ingList = ingList;
    }
    private IngredientList ingList;
    public Ingredient_List_Fragment() {}

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getArguments() != null) {
            mColumnCount = getArguments().getInt(ARG_COLUMN_COUNT);
        }
    }

    private void EditIngredientDialog(Ingredient ingredient) {
        try {
            IngredientList currentList = getIngList();
            // Create fragment manager
            FragmentManager fm = getFragmentManager();
            // Create add ingredient fragment
            Edit_Ingredient editIngredientFragment;
            editIngredientFragment = new Edit_Ingredient();
            // set the ingredient list to add ingredient fragment
            editIngredientFragment.setTargetIngredientList(currentList);

            Bundle args = new Bundle();

            args.putSerializable("EditIngredient",ingredient);
            editIngredientFragment.setArguments(args);
            // show fragment
            editIngredientFragment.show(fm, "Edit_Ingredient_Fragment");

        } catch(Exception e){

        }
    }

    @Override
    public boolean onContextItemSelected(MenuItem item) {
        if (getUserVisibleHint()) {
            int ingredientPosition = item.getGroupId();
            Ingredient tempIngredient;
            // get current listid
            Repository repo = new Repository(this.getContext());
            IngredientList tempIngList = getIngList();
            tempIngredient = tempIngList.getIngredients().get(ingredientPosition);

            switch (item.getItemId()) {
                // Edit
                case 121:
                    EditIngredientDialog(tempIngredient);

                    return true;

                // flag low
                case 122:
                    tempIngredient.setLow(true);
                    repo.updateIngredient(tempIngredient, tempIngList);
                    return false;

                // restock
                case 123:
                    tempIngredient.setLow(false);
                    repo.updateIngredient(tempIngredient, tempIngList);
                    return true;

                // delete
                case 124:
                    repo.deleteIngredient(tempIngredient, tempIngList);
                    return true;
            }
        }
        return false;
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_ingredient_list_layout, container, false);
        recyclerView = view.findViewById(R.id.recyclerViewIngredientListID);
        // Set the adapter
        if (recyclerView instanceof RecyclerView) {
            Context context = view.getContext();
            if (mColumnCount <= 1) {
                recyclerView.setLayoutManager(new LinearLayoutManager(context));
            } else {
                recyclerView.setLayoutManager(new GridLayoutManager(context, mColumnCount));
            }
            recyclerView.setAdapter(new Ingredient_List_Adapter(this.getIngList(), mListener));
        }
        return view;
    }

    @Override
    public void onAttach(Context context) {
        super.onAttach(context);
        if (context instanceof OnListFragmentInteractionListener) {
            mListener = (OnListFragmentInteractionListener) context;
        } else {
            throw new RuntimeException(context.toString() + " must implement OnListFragmentInteractionListener");
        }
    }

    @Override
    public void onDetach() {
        super.onDetach();
        mListener = null;
    }

    public interface OnListFragmentInteractionListener {
        void onListFragmentInteraction(Ingredient item, IngredientList list, Boolean add);
    }
}
